import React from 'react';

export const NotFound: React.FC = () => {
  return <div>NotFound</div>;
};
