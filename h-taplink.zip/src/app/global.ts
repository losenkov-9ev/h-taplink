export const DEFAULT_WINDOW_WIDTH = {
  laptop: 1200,
  tablet: 768,
  mobile: 540,
};
